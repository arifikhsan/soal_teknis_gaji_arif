package com.example.soal_teknis_gaji_arif;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SoalTeknisGajiArifApplication {

    public static void main(String[] args) {
        SpringApplication.run(SoalTeknisGajiArifApplication.class, args);
    }

}
